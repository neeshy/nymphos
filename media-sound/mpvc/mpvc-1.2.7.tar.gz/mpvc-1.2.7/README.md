![mpvc screenshot](https://gitlab.com/mpv-ipc/mpvc/raw/master/res/logo.png "logo")
# mpvc

An mpc-like cli tool for mpv.

This tool is inspired by mpc, a command line interface for the Music Player Daemon.

This project is a fork of [mpv-ipc](https://gitlab.com/mpv-ipc)

## Dependencies

- `mpv`
